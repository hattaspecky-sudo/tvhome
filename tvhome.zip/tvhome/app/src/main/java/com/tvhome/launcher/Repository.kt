package com.tvhome.launcher

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.tv.TvContract
import android.net.Uri
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class Repository(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    /** Builds the whole home screen. Runs on a background thread. */
    fun load(): HomeState {
        val cfg = runCatching { Config.load(context) }.getOrElse { Config("", emptyList(), emptyList()) }

        val ytRows = cfg.youtubeRows.map { r -> HomeRow.Media(r.title, r.videos.map(::youtubeItem)) }

        var playNext = loadPlayNext()
        if (playNext.isEmpty() && BuildConfig.IS_PHONE) playNext = samplePlayNext(cfg)

        val apps = loadApps(cfg.favoriteApps)

        val tmdb = if (cfg.tmdbApiKey.isNotBlank()) runCatching { fetchTmdb(cfg.tmdbApiKey) }.getOrDefault(emptyList())
        else emptyList()

        // Hero priority: TMDB trending > Play Next posters > YouTube thumbnails
        val heroes = tmdb
            .ifEmpty { playNext.filter { it.image != null }.take(6) }
            .ifEmpty { ytRows.flatMap { it.items }.take(6) }

        val rows = buildList {
            if (playNext.isNotEmpty()) add(HomeRow.Media("Continue watching", playNext))
            if (apps.isNotEmpty()) add(HomeRow.Apps("Your apps", apps))
            addAll(ytRows)
        }
        return HomeState(heroes, rows, usesTmdb = tmdb.isNotEmpty())
    }

    // ---------- Play Next (TvProvider Watch Next table) ----------

    private fun loadPlayNext(): List<MediaItem> = try {
        context.contentResolver.query(
            TvContract.WatchNextPrograms.CONTENT_URI, null, null, null,
            "last_engagement_time_utc_millis DESC"
        )?.use { c ->
            fun str(col: String): String? = c.getColumnIndex(col).takeIf { it >= 0 }?.let { c.getString(it) }
            fun num(col: String): Long = c.getColumnIndex(col).takeIf { it >= 0 }?.let { c.getLong(it) } ?: 0L

            val out = mutableListOf<MediaItem>()
            while (c.moveToNext() && out.size < 20) {
                val title = str("title") ?: continue
                val pos = num("last_playback_position_millis")
                val dur = num("duration_millis")
                val season = str("season_display_number")?.let { "S$it" }
                val episode = str("episode_display_number")?.let { "E$it" }
                val ep = listOfNotNull(season, episode).joinToString(" ").ifBlank { null }
                val poster = str("poster_art_uri") ?: str("thumbnail_uri")
                out += MediaItem(
                    title = title,
                    subtitle = ep ?: str("episode_title"),
                    image = poster,
                    backdrop = poster,
                    description = str("short_description"),
                    source = str("package_name")?.let(::appLabel),
                    progress = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else null,
                    intent = str("intent_uri")?.let {
                        runCatching { Intent.parseUri(it, Intent.URI_INTENT_SCHEME) }.getOrNull()
                    },
                )
            }
            out
        } ?: emptyList()
    } catch (e: Exception) {
        // SecurityException = TV doesn't let us read other apps' entries. Row is just hidden.
        emptyList()
    }

    private fun appLabel(pkg: String): String? = runCatching {
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrNull()

    // ---------- Installed apps ----------

    private fun loadApps(favorites: List<String>): List<AppItem> {
        val seen = mutableSetOf<String>()
        val out = mutableListOf<AppItem>()
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)

        for (cat in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName || !seen.add(pkg)) continue
                val launch = (if (cat == Intent.CATEGORY_LEANBACK_LAUNCHER) pm.getLeanbackLaunchIntentForPackage(pkg) else null)
                    ?: pm.getLaunchIntentForPackage(pkg) ?: continue
                val banner = ri.activityInfo.loadBanner(pm) ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                out += AppItem(
                    pkg = pkg,
                    label = ri.loadLabel(pm).toString(),
                    banner = banner?.let { runCatching { it.toBitmap(320, 180).asImageBitmap() }.getOrNull() },
                    icon = if (banner == null) runCatching { ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap() }.getOrNull() else null,
                    intent = launch,
                )
            }
            // On a TV, TV apps are enough. Phone-only apps would just clutter the row.
            if (cat == Intent.CATEGORY_LEANBACK_LAUNCHER && out.isNotEmpty() && !BuildConfig.IS_PHONE) break
        }

        fun rank(a: AppItem) = favorites.indexOf(a.pkg).let { if (it < 0) Int.MAX_VALUE else it }
        return out.sortedWith(compareBy<AppItem>({ rank(it) }, { it.label.lowercase() }))
    }

    // ---------- YouTube ----------

    private fun youtubeItem(v: YtVideo) = MediaItem(
        title = v.title,
        subtitle = "YouTube",
        image = "https://i.ytimg.com/vi/${v.id}/hqdefault.jpg",
        backdrop = "https://i.ytimg.com/vi/${v.id}/maxresdefault.jpg",
        source = "YouTube",
        intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${v.id}")),
    )

    /** Phones have no Play Next database, so the test build fills the row with sample items. */
    private fun samplePlayNext(cfg: Config): List<MediaItem> {
        val progress = listOf(0.62f, 0.3f, 0.68f, 0.15f, 0.8f)
        return cfg.youtubeRows.flatMap { it.videos }.take(5).mapIndexed { i, v ->
            youtubeItem(v).copy(subtitle = "Sample", progress = progress[i % progress.size])
        }
    }

    // ---------- TMDB (optional, needs a free API key in config.json) ----------

    private fun fetchTmdb(key: String): List<MediaItem> {
        val url = URL("https://api.themoviedb.org/3/trending/all/day?api_key=" + URLEncoder.encode(key, "UTF-8"))
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
        }
        val text = try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
        val results = JSONObject(text).getJSONArray("results")
        return (0 until results.length()).mapNotNull { i ->
            val o = results.getJSONObject(i)
            val backdrop = o.optString("backdrop_path").takeIf { it.isNotBlank() && it != "null" } ?: return@mapNotNull null
            val title = o.optString("title").ifBlank { o.optString("name") }
            val year = o.optString("release_date").ifBlank { o.optString("first_air_date") }.take(4)
            val kind = if (o.optString("media_type") == "tv") "Series" else "Movie"
            MediaItem(
                title = title,
                image = "https://image.tmdb.org/t/p/w780$backdrop",
                backdrop = "https://image.tmdb.org/t/p/w1280$backdrop",
                description = o.optString("overview"),
                meta = listOf(year, kind).filter { it.isNotBlank() },
                source = "Trending today",
                // Opens Android TV's global search for the title, which lists the apps that have it
                intent = Intent("android.search.action.GLOBAL_SEARCH").putExtra(SearchManager.QUERY, title),
            )
        }.take(8)
    }
}
