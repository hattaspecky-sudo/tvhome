package com.tvhome.launcher

import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap

/** Anything shown as a poster card or hero banner. */
data class MediaItem(
    val title: String,
    val subtitle: String? = null,
    val image: String? = null,        // card artwork (URL or content:// URI)
    val backdrop: String? = null,     // wide hero artwork, falls back to image
    val description: String? = null,
    val meta: List<String> = emptyList(),
    val source: String? = null,       // "YouTube", "Netflix", "Trending today"...
    val progress: Float? = null,      // 0..1, Play Next only
    val intent: Intent? = null,
)

data class AppItem(
    val pkg: String,
    val label: String,
    val banner: ImageBitmap?,         // 16:9 TV banner if the app has one
    val icon: ImageBitmap?,           // fallback square icon
    val intent: Intent,
)

sealed class HomeRow(val title: String) {
    class Media(title: String, val items: List<MediaItem>) : HomeRow(title)
    class Apps(title: String, val apps: List<AppItem>) : HomeRow(title)
}

data class HomeState(
    val heroes: List<MediaItem> = emptyList(),
    val rows: List<HomeRow> = emptyList(),
    val usesTmdb: Boolean = false,
)
