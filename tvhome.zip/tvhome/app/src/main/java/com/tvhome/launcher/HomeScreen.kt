@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.tvhome.launcher

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ScreenBg = Color(0xFF08090B)
private val Panel = Color(0xFF1B1D21)
private val Dim = Color(0xFF9B9A96)
private val Soft = Color(0xFFCFCDC8)
private val Accent = Color(0xFFE8B04A)
private val Progress = Color(0xFFFF3B30)
private val SideGutter = 56.dp   // TV overscan-safe margin

@Composable
fun HomeScreen(repo: Repository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var state by remember { mutableStateOf(HomeState()) }

    // Reload whenever Home comes back to the front, so Play Next and apps stay current
    LifecycleResumeEffect(Unit) {
        val job = scope.launch { state = withContext(Dispatchers.IO) { repo.load() } }
        onPauseOrDispose { job.cancel() }
    }

    // As a Home screen, Back should never exit. It just scrolls back to the top.
    BackHandler(enabled = BuildConfig.IS_HOME) { scope.launch { listState.animateScrollToItem(0) } }

    val heroes = state.heroes
    var heroIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(heroes) {
        heroIndex = 0
        while (heroes.size > 1) {
            delay(8_000)
            heroIndex = (heroIndex + 1) % heroes.size
        }
    }
    val hero = heroes.getOrNull(heroIndex)

    val watchFocus = remember { FocusRequester() }
    LaunchedEffect(heroes.isNotEmpty()) {
        if (heroes.isNotEmpty()) runCatching { watchFocus.requestFocus() }
    }

    val heroHeight = (LocalConfiguration.current.screenHeightDp * 0.66f).dp

    Box(Modifier.fillMaxSize().background(ScreenBg)) {
        HeroBackdrop(hero, heroHeight + 24.dp)
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            item(key = "hero") {
                HeroInfo(hero, heroHeight, state.usesTmdb, watchFocus) { open(context, hero?.intent) }
            }
            items(state.rows, key = { it.title }) { row -> ContentRow(row, context) }
        }
    }
}

// ---------- Hero ----------

@Composable
private fun HeroBackdrop(hero: MediaItem?, height: Dp) {
    Box(Modifier.fillMaxWidth().height(height)) {
        Crossfade(targetState = hero, animationSpec = tween(1100), label = "hero") { item ->
            if (item != null) {
                // Slow "Ken Burns" zoom while each banner is showing
                val zoom = remember(item) { Animatable(1f) }
                LaunchedEffect(item) { zoom.animateTo(1.09f, tween(10_000, easing = LinearEasing)) }
                AsyncImage(
                    model = item.backdrop ?: item.image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        scaleX = zoom.value
                        scaleY = zoom.value
                    },
                )
            }
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(
                    0f to ScreenBg.copy(alpha = 0.92f),
                    0.42f to ScreenBg.copy(alpha = 0.55f),
                    0.7f to Color.Transparent,
                )
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.55f to Color.Transparent, 1f to ScreenBg)
            )
        )
    }
}

@Composable
private fun HeroInfo(
    hero: MediaItem?,
    height: Dp,
    usesTmdb: Boolean,
    watchFocus: FocusRequester,
    onWatch: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .height(height)
            .padding(start = SideGutter, end = SideGutter, top = 24.dp, bottom = 8.dp)
    ) {
        TopBar()
        Spacer(Modifier.weight(1f))
        Crossfade(targetState = hero, animationSpec = tween(600), label = "heroText") { item ->
            if (item != null) {
                Column(Modifier.widthIn(max = 560.dp)) {
                    item.source?.let {
                        Text(it.uppercase(), fontSize = 13.sp, letterSpacing = 1.2.sp, color = Dim, fontWeight = FontWeight.Medium)
                    }
                    Text(
                        item.title,
                        fontSize = 46.sp,
                        lineHeight = 50.sp,
                        fontFamily = FontFamily.Serif,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                    if (item.meta.isNotEmpty()) {
                        Text(item.meta.joinToString("  ·  "), fontSize = 15.sp, color = Soft)
                    }
                    item.description?.takeIf { it.isNotBlank() }?.let {
                        Text(
                            it, fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFFBEBCB7),
                            maxLines = 3, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 480.dp).padding(top = 8.dp),
                        )
                    }
                }
            }
        }
        // Button sits outside the crossfade so it keeps focus while banners rotate
        if (hero != null) {
            Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onWatch, modifier = Modifier.focusRequester(watchFocus)) { Text("▶  Watch") }
                if (usesTmdb) Text("Artwork: TMDB", fontSize = 11.sp, color = Dim, modifier = Modifier.padding(start = 16.dp))
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("For you", fontSize = 17.sp, color = Color.White, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Clock()
        Box(
            Modifier.padding(start = 14.dp).size(34.dp).clip(CircleShape).background(Accent),
            contentAlignment = Alignment.Center,
        ) { Text("H", color = Color(0xFF2A1D05), fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun Clock() {
    val time by produceState(now()) {
        while (true) {
            value = now()
            delay(15_000)
        }
    }
    Text(time, fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Medium)
}

private fun now(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

// ---------- Rows ----------

@Composable
private fun ContentRow(row: HomeRow, context: Context) {
    Column {
        Text(
            row.title,
            fontSize = 17.sp,
            color = Color(0xFFE3E1DC),
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = SideGutter, bottom = 10.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = SideGutter, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            when (row) {
                is HomeRow.Media -> items(row.items) { MediaCard(it) { open(context, it.intent) } }
                is HomeRow.Apps -> items(row.apps, key = { it.pkg }) { AppCard(it) { open(context, it.intent) } }
            }
        }
    }
}

private val focusBorder = Border(BorderStroke(3.dp, Color.White))

@Composable
private fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.size(236.dp, 133.dp),
        shape = CardDefaults.shape(RoundedCornerShape(8.dp)),
        scale = CardDefaults.scale(focusedScale = 1.06f),
        border = CardDefaults.border(focusedBorder = focusBorder),
        colors = CardDefaults.colors(containerColor = Panel),
    ) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(
                model = item.image,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color(0xD9000000))))
            Column(Modifier.align(Alignment.BottomStart).padding(start = 10.dp, end = 10.dp, bottom = 10.dp)) {
                Text(item.title, fontSize = 14.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                item.subtitle?.let { Text(it, fontSize = 12.sp, color = Soft, maxLines = 1) }
            }
            item.progress?.let { p ->
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color(0x40FFFFFF))) {
                    Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Progress))
                }
            }
        }
    }
}

@Composable
private fun AppCard(app: AppItem, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.size(188.dp, 106.dp),
        shape = CardDefaults.shape(RoundedCornerShape(8.dp)),
        scale = CardDefaults.scale(focusedScale = 1.06f),
        border = CardDefaults.border(focusedBorder = focusBorder),
        colors = CardDefaults.colors(containerColor = Panel),
    ) {
        if (app.banner != null) {
            Image(app.banner, app.label, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Column(
                Modifier.fillMaxSize().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                app.icon?.let { Image(it, null, Modifier.size(44.dp)) }
                Text(app.label, fontSize = 13.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

private fun open(context: Context, intent: Intent?) {
    if (intent == null) return
    try {
        context.startActivity(Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "Couldn't open that", Toast.LENGTH_SHORT).show()
    }
}
