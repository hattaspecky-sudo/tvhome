package com.tvhome.launcher

import android.content.Context
import org.json.JSONObject
import java.io.File

data class YtVideo(val id: String, val title: String)
data class YtRow(val title: String, val videos: List<YtVideo>)

data class Config(
    val tmdbApiKey: String,
    val favoriteApps: List<String>,
    val youtubeRows: List<YtRow>,
) {
    companion object {
        /**
         * Reads config.json. An override pushed with
         *   adb push config.json /sdcard/Android/data/com.tvhome.launcher/files/config.json
         * wins over the built-in default in assets/.
         * (The phone setup page in a later round will write this same file.)
         */
        fun load(context: Context): Config {
            val override = context.getExternalFilesDir(null)?.let { File(it, "config.json") }
            val text = if (override != null && override.exists()) override.readText()
            else context.assets.open("config.json").bufferedReader().use { it.readText() }
            return parse(text)
        }

        private fun parse(text: String): Config {
            val o = JSONObject(text)
            val fav = o.optJSONArray("favoriteApps")
            val rows = o.optJSONArray("youtubeRows")
            return Config(
                tmdbApiKey = o.optString("tmdbApiKey"),
                favoriteApps = fav?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList(),
                youtubeRows = rows?.let { a ->
                    (0 until a.length()).map { i ->
                        val r = a.getJSONObject(i)
                        val v = r.getJSONArray("videos")
                        YtRow(
                            r.getString("title"),
                            (0 until v.length()).map { j ->
                                val x = v.getJSONObject(j)
                                YtVideo(x.getString("id"), x.optString("title", "YouTube video"))
                            }
                        )
                    }
                } ?: emptyList(),
            )
        }
    }
}
